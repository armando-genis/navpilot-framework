#include "pointcloud_rotation_node.h"

pointcloud_rotation_node::pointcloud_rotation_node(const rclcpp::NodeOptions& options)
    : Node("pointcloud_rotation_node", options)
{

    // ==================  variables for ground remove  ==================
    this->declare_parameter("num_seg_", 50);
    this->declare_parameter("num_iter_", 25);
    this->declare_parameter("num_lpr_", 10);
    this->declare_parameter("th_seeds_", 1.0);
    this->declare_parameter("th_dist_", 0.3);
    this->declare_parameter("sensor_height_", 1.73);

    this->get_parameter("num_seg_", num_seg_);
    this->get_parameter("num_iter_", num_iter_);
    this->get_parameter("num_lpr_", num_lpr_);
    this->get_parameter("th_seeds_", th_seeds_);
    this->get_parameter("th_dist_", th_dist_);
    this->get_parameter("sensor_height_", sensor_height_);

    // ==================  variables for pointcloud voxel  ==================
    this->declare_parameter("voxel_leaf_size_x", double(0.0));
    this->declare_parameter("voxel_leaf_size_y", double(0.0));
    this->declare_parameter("voxel_leaf_size_z", double(0.0));
    this->declare_parameter("voxel_condition", false);

    this->get_parameter("voxel_leaf_size_x", voxel_leaf_size_x_);
    this->get_parameter("voxel_leaf_size_y", voxel_leaf_size_y_);
    this->get_parameter("voxel_leaf_size_z", voxel_leaf_size_z_);
    this->get_parameter("voxel_condition", voxel_condition);

    // ============== variables for robot footprint condition  ==============
    this->declare_parameter("robot_footprint_condition", false);
    this->get_parameter("robot_footprint_condition", robot_footprint_condition);

    // ==================  variables for ROI boundaries  ==================

    this->declare_parameter("roi_max_x_", double(0.0));
    this->declare_parameter("roi_max_y_", double(0.0));
    this->declare_parameter("roi_max_z_", double(0.0));

    this->declare_parameter("roi_min_x_", double(0.0));
    this->declare_parameter("roi_min_y_", double(0.0));
    this->declare_parameter("roi_min_z_", double(0.0));

    this->get_parameter("roi_max_x_", roi_max_x_);
    this->get_parameter("roi_max_y_", roi_max_y_);
    this->get_parameter("roi_max_z_", roi_max_z_);

    this->get_parameter("roi_min_x_", roi_min_x_);
    this->get_parameter("roi_min_y_", roi_min_y_);
    this->get_parameter("roi_min_z_", roi_min_z_);

    // ==================  variables for sensor_rotation_y  ==================
    this->declare_parameter("sensor_rotation_y_", 0.0);
    this->get_parameter("sensor_rotation_y_", sensor_rotation_y_);

    // ==================  variables for pointcloud topic  ==================
    this->declare_parameter("pointcloud_topic", std::string("/none"));
    this->declare_parameter("output_topic", std::string("/none"));
    this->declare_parameter("output_topic_ground", std::string("/none"));
    this->declare_parameter("robot_footprint_topic", std::string("/robot_footprint_polygon"));

    this->get_parameter("pointcloud_topic", pointcloud_topic);
    this->get_parameter("output_topic", output_topic);
    this->get_parameter("output_topic_ground", output_topic_ground);
    
    std::string robot_footprint_topic;
    this->get_parameter("robot_footprint_topic", robot_footprint_topic);

    // ============== variables for robot footprint  ==============
    this->declare_parameter("robot_footprint_x_max", 0.0);
    this->declare_parameter("robot_footprint_y_max", 0.0);
    this->declare_parameter("robot_footprint_z_max", 0.0);
    this->declare_parameter("robot_footprint_x_min", 0.0);
    this->declare_parameter("robot_footprint_y_min", 0.0);
    this->declare_parameter("robot_footprint_z_min", 0.0);
    
    this->get_parameter("robot_footprint_x_max", robot_footprint_x_max);
    this->get_parameter("robot_footprint_y_max", robot_footprint_y_max);
    this->get_parameter("robot_footprint_z_max", robot_footprint_z_max);
    this->get_parameter("robot_footprint_x_min", robot_footprint_x_min);
    this->get_parameter("robot_footprint_y_min", robot_footprint_y_min);
    this->get_parameter("robot_footprint_z_min", robot_footprint_z_min);


    sub_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(pointcloud_topic, 10, std::bind(&pointcloud_rotation_node::pointCloudCallback, this, std::placeholders::_1));
    pub_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(output_topic, 10);
    pub_ground_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(output_topic_ground, 10);
    pub_marker_ = this->create_publisher<visualization_msgs::msg::Marker>(robot_footprint_topic, 10);

    ROI_MAX_POINT = Eigen::Vector4f(roi_max_x_, roi_max_y_, roi_max_z_, 1);
    ROI_MIN_POINT = Eigen::Vector4f(roi_min_x_, roi_min_y_, roi_min_z_, 1);

    // Initialize reusable point clouds once
    input_cloud_.reset(new pcl::PointCloud<pcl::PointXYZI>());
    transformed_cloud_.reset(new pcl::PointCloud<pcl::PointXYZI>());
    cloud_roi_.reset(new pcl::PointCloud<pcl::PointXYZI>());
    filtered_cloud_.reset(new pcl::PointCloud<pcl::PointXYZI>());
    notground_points_.reset(new pcl::PointCloud<pcl::PointXYZI>());
    seed_points_.reset(new pcl::PointCloud<pcl::PointXYZI>());

    // Precompute rotation matrix (cos/sin once)
    const float c = std::cos(sensor_rotation_y_);
    const float s = std::sin(sensor_rotation_y_);
    rotation_matrix_ = Eigen::Matrix4f::Identity();
    rotation_matrix_(0, 0) = c;
    rotation_matrix_(0, 2) = s;
    rotation_matrix_(2, 0) = -s;
    rotation_matrix_(2, 2) = c;

    // Configure ROI and voxel filters once (reused every callback)
    roi_filter_.setMin(ROI_MIN_POINT);
    roi_filter_.setMax(ROI_MAX_POINT);
    voxel_filter_.setLeafSize(voxel_leaf_size_x_, voxel_leaf_size_y_, voxel_leaf_size_z_);

    // Configure footprint CropBox once (negative = keep points outside box)
    footprint_filter_.setMin(Eigen::Vector4f(robot_footprint_x_min, robot_footprint_y_min, robot_footprint_z_min, 1));
    footprint_filter_.setMax(Eigen::Vector4f(robot_footprint_x_max, robot_footprint_y_max, robot_footprint_z_max, 1));
    footprint_filter_.setNegative(true);

    // Print the parameters
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->pointcloud_topic: %s \033[0m", pointcloud_topic.c_str());
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->output_topic: %s \033[0m", output_topic.c_str());
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->output_topic_ground: %s \033[0m", output_topic_ground.c_str());
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->robot_footprint_topic: %s \033[0m", robot_footprint_topic.c_str());

    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->voxel_leaf_size_x: %f \033[0m", voxel_leaf_size_x_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->voxel_leaf_size_y: %f \033[0m", voxel_leaf_size_y_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->voxel_leaf_size_z: %f \033[0m", voxel_leaf_size_z_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->voxel_condition: %d \033[0m", voxel_condition);

    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->robot_footprint_condition: %d \033[0m", robot_footprint_condition);

    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->roi_max_x: %f \033[0m", roi_max_x_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->roi_max_y: %f \033[0m", roi_max_y_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->roi_max_z: %f \033[0m", roi_max_z_);

    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->roi_min_x: %f \033[0m", roi_min_x_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->roi_min_y: %f \033[0m", roi_min_y_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m---->roi_min_z: %f \033[0m", roi_min_z_);

    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> num_seg: %d \033[0m", num_seg_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> num_iter: %d \033[0m", num_iter_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> num_lpr: %d \033[0m", num_lpr_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> th_seeds: %f \033[0m", th_seeds_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> th_dist: %f \033[0m", th_dist_);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> sensor_height: %f \033[0m", sensor_height_);

    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> sensor_rotation_y: %f \033[0m", sensor_rotation_y_);

    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> robot_footprint_x_max: %f \033[0m", robot_footprint_x_max);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> robot_footprint_y_max: %f \033[0m", robot_footprint_y_max);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> robot_footprint_z_max: %f \033[0m", robot_footprint_z_max);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> robot_footprint_x_min: %f \033[0m", robot_footprint_x_min);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> robot_footprint_y_min: %f \033[0m", robot_footprint_y_min);
    RCLCPP_INFO(this->get_logger(), "\033[1;34m----> robot_footprint_z_min: %f \033[0m", robot_footprint_z_min);

    RCLCPP_INFO(this->get_logger(), "\033[1;32m----> pointcloud_rotation_node initialized.\033[0m");
}

pointcloud_rotation_node::~pointcloud_rotation_node()
{
}

void pointcloud_rotation_node::pointCloudCallback(const sensor_msgs::msg::PointCloud2::SharedPtr msg)
{
    if (msg->data.empty())
    {
        RCLCPP_WARN(this->get_logger(), "\033[1;31m----> pointcloud_rotation_node: msg is empty.\033[0m");
        return;
    }

    // Skip processing if cloud too small (sensor glitches)
    if (msg->width * msg->height < 100)
    {
        return;
    }

    pcl::fromROSMsg(*msg, *input_cloud_);

    // Remove NaNs immediately (many LiDAR drivers include NaNs and they slow downstream filters)
    pcl::removeNaNFromPointCloud(*input_cloud_, *input_cloud_, nan_indices_);

    pcl::transformPointCloud(*input_cloud_, *transformed_cloud_, rotation_matrix_);

    // Remove robot footprint using CropBox (SIMD-optimized, 2–5x faster than manual loop)
    // Filter to cloud_roi_ to avoid in-place read/write; then ROI uses that or transformed_cloud_
    if (robot_footprint_condition)
    {
        footprint_filter_.setInputCloud(transformed_cloud_);
        footprint_filter_.filter(*cloud_roi_);
        roi_filter_.setInputCloud(cloud_roi_);
        roi_filter_.filter(*filtered_cloud_);
    }
    else
    {
        roi_filter_.setInputCloud(transformed_cloud_);
        roi_filter_.filter(*cloud_roi_);
    }

    sensor_msgs::msg::PointCloud2 ground_msg;
    pcl::toROSMsg(*transformed_cloud_, ground_msg);
    ground_msg.header.frame_id = msg->header.frame_id;
    ground_msg.header.stamp = msg->header.stamp;
    pub_->publish(ground_msg);

    if (voxel_condition)
    {
        // When footprint is on, ROI result is in filtered_cloud_; otherwise in cloud_roi_
        if (robot_footprint_condition)
        {
            voxel_filter_.setInputCloud(filtered_cloud_);
            voxel_filter_.filter(*cloud_roi_);
        }
        else
        {
            voxel_filter_.setInputCloud(cloud_roi_);
            voxel_filter_.filter(*filtered_cloud_);
        }

        pcl::PointCloud<pcl::PointXYZI>::Ptr& cloud_for_ground = robot_footprint_condition ? cloud_roi_ : filtered_cloud_;
        seed_points_->clear();
        extractInitialSeeds(cloud_for_ground, seed_points_);

        Model model = estimatePlane(*seed_points_);

        notground_points_->clear();
        notground_points_->points.reserve(cloud_for_ground->size());
        for (const auto& point : cloud_for_ground->points)
        {
            float dist = model.normal(0) * point.x + model.normal(1) * point.y + model.normal(2) * point.z + model.d;
            if (dist >= th_dist_)
            {
                notground_points_->points.push_back(point);
            }
        }

        sensor_msgs::msg::PointCloud2 ground_msg;
        pcl::toROSMsg(*notground_points_, ground_msg);
        ground_msg.header = msg->header;
        ground_msg.header.frame_id = msg->header.frame_id;
        pub_ground_->publish(ground_msg);
    }
    else
    {
        // When footprint is on, ROI result is in filtered_cloud_; otherwise in cloud_roi_
        pcl::PointCloud<pcl::PointXYZI>::Ptr& to_publish = robot_footprint_condition ? filtered_cloud_ : cloud_roi_;
        sensor_msgs::msg::PointCloud2 downsampled_cloud_msg;
        pcl::toROSMsg(*to_publish, downsampled_cloud_msg);
        downsampled_cloud_msg.header = msg->header;
        downsampled_cloud_msg.header.frame_id = msg->header.frame_id;
        pub_ground_->publish(downsampled_cloud_msg);
    }

    visualization_msgs::msg::Marker robot_marker = createRobotFootprintMarker();
    robot_marker.header.frame_id = msg->header.frame_id;
    robot_marker.header.stamp = msg->header.stamp;
    pub_marker_->publish(robot_marker);
}

pointcloud_rotation_node::Model pointcloud_rotation_node::estimatePlane(const pcl::PointCloud<pcl::PointXYZI> &seed_points)
{
    Eigen::Matrix3f cov_matrix;
    Eigen::Vector4f centroid;
    pcl::computeMeanAndCovarianceMatrix(seed_points, cov_matrix, centroid);

    Eigen::JacobiSVD<Eigen::MatrixXf> svd(cov_matrix, Eigen::ComputeFullU);
    Model model;
    model.normal = svd.matrixU().col(2);
    model.d = -(model.normal.transpose() * centroid.head<3>())(0, 0);

    return model;
}

void pointcloud_rotation_node::extractInitialSeeds(const pcl::PointCloud<pcl::PointXYZI>::Ptr &cloud_in, pcl::PointCloud<pcl::PointXYZI>::Ptr &seed_points)
{
    // Step 1: Partition the cloud based on z value
    auto partition_point = std::partition(cloud_in->points.begin(), cloud_in->points.end(), [&](const pcl::PointXYZI &point)
                                          { return point.z < -1.5 * sensor_height_; });

    // Step 2: The "above threshold" points are now in [partition_point, cloud_in->points.end()]
    pcl::PointCloud<pcl::PointXYZI>::Ptr filtered_cloud(new pcl::PointCloud<pcl::PointXYZI>());
    filtered_cloud->points.assign(partition_point, cloud_in->points.end());

    // Step 3: Compute the LPR height by averaging the first 'num_lpr_' points in the filtered cloud
    double LPR_height = 0.0;
    int num_lpr = std::min(num_lpr_, static_cast<int>(filtered_cloud->points.size()));

    for (int i = 0; i < num_lpr; ++i)
    {
        LPR_height += filtered_cloud->points[i].z;
    }
    LPR_height /= num_lpr;

    // Step 4: Add points below the LPR height + th_seeds_ to seed_points
    seed_points->points.clear();
    seed_points->points.reserve(filtered_cloud->points.size());
    for (const auto &point : filtered_cloud->points)
    {
        if (point.z < LPR_height + th_seeds_)
        {
            seed_points->points.push_back(point);
        }
    }
}

visualization_msgs::msg::Marker pointcloud_rotation_node::createRobotFootprintMarker()
{
    visualization_msgs::msg::Marker marker;
    
    // Set header
    marker.header.stamp = this->now();
    marker.header.frame_id = "velodyne";
    
    // Set marker properties
    marker.ns = "robot_footprint";
    marker.id = 0;
    marker.type = visualization_msgs::msg::Marker::CUBE;
    marker.action = visualization_msgs::msg::Marker::ADD;
    
    // Calculate center position
    marker.pose.position.x = (robot_footprint_x_max + robot_footprint_x_min) / 2.0;
    marker.pose.position.y = (robot_footprint_y_max + robot_footprint_y_min) / 2.0;
    marker.pose.position.z = (robot_footprint_z_max + robot_footprint_z_min) / 2.0;
    
    // Set orientation (no rotation)
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;
    
    // Set scale (size of the cube)
    marker.scale.x = robot_footprint_x_max - robot_footprint_x_min;
    marker.scale.y = robot_footprint_y_max - robot_footprint_y_min;
    marker.scale.z = robot_footprint_z_max - robot_footprint_z_min;
    
    // Set color (red with transparency)
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    marker.color.a = 0.5; // Semi-transparent
    
    // Set lifetime (0 means permanent)
    marker.lifetime = rclcpp::Duration(0, 0);
    
    return marker;
}

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto options = rclcpp::NodeOptions().use_intra_process_comms(true);
    auto node = std::make_shared<pointcloud_rotation_node>(options);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}