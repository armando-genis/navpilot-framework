// Copyright 2019 Bold Hearts
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef V4L2_CAMERA__V4L2_CAMERA_HPP_
#define V4L2_CAMERA__V4L2_CAMERA_HPP_

#include "v4l2_camera/v4l2_camera.hpp"
#include "v4l2_camera/v4l2_camera_device.hpp"

#include <camera_info_manager/camera_info_manager.hpp>
#include <image_transport/image_transport.hpp>
#include <diagnostic_updater/diagnostic_updater.hpp>

#include <ostream>
#include <rclcpp/rclcpp.hpp>
#include <rcl_interfaces/msg/parameter.hpp>

#include <memory>
#include <string>
#include <map>
#include <vector>
#include <optional>
#include <mutex>


#include "v4l2_camera/visibility_control.h"
#include "v4l2_camera/multi_cam_synchronizer.hpp"


#ifdef ENABLE_CUDA
#include <nppdefs.h>
#include <nppi_support_functions.h>
#endif

namespace v4l2_camera
{
#ifdef ENABLE_CUDA
struct GPUMemoryManager
{
 public:
  // helper structure to handle GPU memory
  Npp8u * dev_ptr;
  int step_bytes;
  int allocated_size;

  explicit GPUMemoryManager()
  {
    dev_ptr = nullptr;
    step_bytes = 0;
    allocated_size = 0;
  }

  ~GPUMemoryManager()
  {
    if (dev_ptr != nullptr) {
      nppiFree(dev_ptr);
    }
  }

  void Allocate(int width, int height)
  {
    if (dev_ptr == nullptr || allocated_size < height * step_bytes) {
      dev_ptr = nppiMalloc_8u_C3(width, height, &step_bytes);
      allocated_size = height * step_bytes;
    }
  }
};


void cudaErrorCheck(const cudaError_t e)
{
  if (e != cudaSuccess) {
    std::stringstream ss;
    ss << cudaGetErrorName(e) << " : " << cudaGetErrorString(e);
    throw std::runtime_error{ss.str()};
  }
}
#endif

class V4L2Camera : public rclcpp::Node
{
public:
  explicit V4L2Camera(rclcpp::NodeOptions const & options);

  virtual ~V4L2Camera();

private:
  using ImageSize = std::vector<int64_t>;
  using TimePerFrame = std::vector<int64_t>;

  // Single camera mode
  std::shared_ptr<V4l2CameraDevice> camera_;
  std::thread capture_thread_;

  // Publisher used for intra process comm
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr image_pub_;
  rclcpp::Publisher<sensor_msgs::msg::CameraInfo>::SharedPtr info_pub_;

  // Publisher used for inter process comm
  image_transport::CameraPublisher camera_transport_pub_;

  std::shared_ptr<camera_info_manager::CameraInfoManager> cinfo_;

  // multi-cam mode
  std::vector<std::thread> capture_threads_;
  std::vector<std::shared_ptr<V4l2CameraDevice>> cameras_;
  std::thread process_thread_;

  std::vector<std::string> video_devices_;
  uint64_t sync_tolerance_ns_{10'000'000ULL};  // 10ms
  size_t max_queue_{10};
  bool sync_enabled_{false};  // Enable/disable frame synchronization

  // Per-camera publishers for multi-camera mode
  std::vector<rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr> multi_image_pubs_;
  std::vector<rclcpp::Publisher<sensor_msgs::msg::CameraInfo>::SharedPtr> multi_info_pubs_;
  std::vector<image_transport::CameraPublisher> multi_camera_transport_pubs_;
  
  // Cached data per camera for performance (avoid recreating each frame)
  std::vector<sensor_msgs::msg::CameraInfo> cached_camera_infos_;
  std::vector<std::string> camera_frame_ids_;

  MultiCamSynchronizer<sensor_msgs::msg::Image::UniquePtr> sync_{1, 10'000'000ULL, 10};

  std::atomic<bool> canceled_;

  std::string camera_frame_id_;
  std::string output_encoding_;

  std::map<std::string, int32_t> control_name_to_id_;

  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr on_set_parameters_callback_;

  double publish_rate_;
  rclcpp::TimerBase::SharedPtr image_pub_timer_;

  bool publish_next_frame_;
  bool use_image_transport_;

  std::shared_ptr<diagnostic_updater::Updater> diag_updater_;
  std::shared_ptr<diagnostic_updater::CompositeDiagnosticTask> diag_composer_;

  // To keep publishing diagnostics even after the constuctor of V4L2Camera class fail,
  // this FunctionDiagnosticTask should be declared as a class member due to lifetime
  std::shared_ptr<diagnostic_updater::FunctionDiagnosticTask> device_node_existence_diag_;

  std::optional<TimePerFrame> time_per_frame_;
  std::optional<double> min_ok_rate_;
  std::optional<double> max_ok_rate_;
  std::optional<double> min_warn_rate_;
  std::optional<double> max_warn_rate_;
  int observed_frames_transition_;

  // Timestamp settings (needed for multi-camera mode)
  bool use_v4l2_buffer_timestamps_;
  rclcpp::Duration timestamp_offset_duration_;

  std::mutex lock_;

#ifdef ENABLE_CUDA
  // Memory region to communicate with GPU
  std::allocator<GPUMemoryManager> allocator_;
  std::shared_ptr<GPUMemoryManager> src_dev_;
  std::shared_ptr<GPUMemoryManager> dst_dev_;
#endif

  void createParameters();
  bool handleParameter(rclcpp::Parameter const & param);

  bool requestPixelFormat(std::string const & fourcc);
  bool requestImageSize(ImageSize const & size);

  bool requestTimePerFrame(TimePerFrame const & timePerFrame);

  sensor_msgs::msg::Image::UniquePtr convert(sensor_msgs::msg::Image const & img) const;
#ifdef ENABLE_CUDA
  sensor_msgs::msg::Image::UniquePtr convertOnGpu(sensor_msgs::msg::Image const & img);
#endif

  bool checkCameraInfo(
    sensor_msgs::msg::Image const & img,
    sensor_msgs::msg::CameraInfo const & ci);

  // Multi-camera methods
  void startMultiCamera();
  void captureLoopMulti(size_t cam_id);
  void processLoopMulti();
};

}  // namespace v4l2_camera

#endif  // V4L2_CAMERA__V4L2_CAMERA_HPP_
